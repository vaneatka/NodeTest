import React from 'react';
import MainNav from './MainNav'
import FooterNav from './FooterNav';


function App() {
  return (
    <div className="App">     
    <MainNav /> 
    <hr/>
    <FooterNav/>
    </div>
  );
}

export default App;
