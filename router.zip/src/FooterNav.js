import React, { Component } from 'react'
import {BrowserRouter as Router, Link, Route} from 'react-router-dom'; 
import About from './About'
import Terms from './Terms'
class FooterNav extends Component{

    render(){
        return(

            <Router>
            <nav>
                <Link to='/currency/about'>About Us</Link> <br/>
                <Link to='/currency/terms'>Terms</Link> <br/>
                

                <hr/>
               
                <Route path='/currency/about' component={About}/>
                <Route path='/currency/terms' component={Terms}/>

               
            </nav>
        </Router>
        )
    }
}

export default FooterNav