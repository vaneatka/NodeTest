import React, { Component } from 'react';

class Terms extends Component{
    render(){
        return(
            <h1>This is the Terms Page</h1>
        )
    }
}

export default Terms