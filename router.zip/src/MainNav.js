import React, { Component } from 'react'
import {BrowserRouter as Router, Link, Route} from 'react-router-dom'; 
import Courrency from './Courrency';
class MainNav extends Component{
    render() {
        return(
        <Router>
            <nav>
                <Link to='/currency/eur'>Euro</Link> <br/>
                <Link to='/currency/usd'>USD</Link> <br/>
                <Link to='/currency/gbp'>GBP</Link>  

                <hr/>
                {/* <Courrency/> */}

                <Route path='/currency/:code' component={Courrency}/>


                {/* <Route path='/r2' exact component={Courrency}/>
                <Route path='/r3' exact component={Courrency}/> */}
            </nav>
        </Router>
        )
    }
}

export default MainNav;