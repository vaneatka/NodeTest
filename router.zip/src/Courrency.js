import React, { Component } from 'react';
import axios from 'axios'

const KEY = 'd04c62155a75be97006b26f71311e81d'
const URL =`http://data.fixer.io/api/latest?access_key=${KEY}`

class Courrency extends Component{
    constructor(){
        super();
    this.state = {
        rates : {}
    }
    
    var _this =this;
    axios.get ( URL )
    .then((response)=>{    
        // rate = response.data.rates[code.toUpperCase()];           
        _this.setState({rates : response.data.rates})
    })
    
}

render(){
     let code = this.props.match.params.code;
        
       
        return (
            <div>Where is my {this.state.rates[code.toUpperCase()]} ?</div>
        )
    }
}
export default Courrency;