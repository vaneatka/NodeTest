import React from 'react';
import Button from './button/Button';
import './App.css';
import CountButton from './button/CountButton'

function App() {
  return (
    <div>
    <Button text = "OK" type = "danger"/>
    <Button text = "More Than OK"/>
    <Button text = "Not OK!"/>
    <Button text = "So So!" disabled = {true}/>
    <hr/>
    <CountButton text= "Please wait......" delay = "10" disabled = {true}/>
    </div>
  );
}

export default App;
