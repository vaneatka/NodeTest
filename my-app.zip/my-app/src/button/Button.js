import React  from 'react';
import './Button.css';

class Button extends React.Component {

    constructor(props){
        super(props);
        this.text = this.props.text;
        this.state = {
            disabled : this.props.disabled
        }
    }

    render(){
        let {type} = this.props;
        
        let styles = {};
        if (type == "danger"){
            styles = {
                backgroundColor : "red"
            }
        }
       
        return(
            <button className = "my-button" style = {styles} disabled = {this.state.disabled}>{this.text}</button>
        )
    }
}

export default Button;